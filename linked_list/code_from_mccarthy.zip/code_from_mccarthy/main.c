//
//  main.c
//  linked_list
//
//  Created by William McCarthy on 064//20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include "slist.h"
#include "dlist.h"

//-------------------------------------------------
int main(int argc, const char* argv[]) {
  slist_test();
  dlist_test();

  return 0;
}
