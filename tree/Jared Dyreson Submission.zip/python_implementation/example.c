/*
 This program will read in the source document and prints in alphabetical order each group of variables names that are identical in the first 6 characters.....
*/

int main(){
  return 0;
}
