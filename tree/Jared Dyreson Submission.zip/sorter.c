#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "src/tree.h"
#include "src/file_struct.h"

void sorter(const char* path){
  struct file_* f_a = file_constructor(path, false);
  printf("//=========== TESTING TREE: %s =====================///\n\n", f_a->file_path);
  tree* tree = tree_create();
  const char* noise_words[BUFSIZ] = {
    "the", "and", "uh", "umm"
  };
  struct tnode *root, *sorted_root, *item;

  sorted_root = NULL;
  
  for(int i = 0; i < f_a->length; ++i){
    char* mutate = strdup(f_a->contents[i]);
    char* token = strtok(mutate, " ");
    while(token != NULL){
      root = tree_add(tree, token, strlen(token), i+1);
      token = strtok(NULL, " ");
    }
  }
  while((item = loop_tree(tree->root)) != NULL){
    printf("item: %s\n", item->word);
  } 
  tree_print(tree);
  tree_clear(tree);
  free(tree);
  file_destructor(f_a);
}

int main(int argc, const char* argv[]) {
  if(argc < 2){
    fprintf(stderr, "Usage: %s <filename>\n", *argv++);
    return -1;
  }
  ++argv;
  sorter(*argv++);
  return 0;
}
