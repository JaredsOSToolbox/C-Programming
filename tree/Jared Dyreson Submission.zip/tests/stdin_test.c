#include <stdio.h>
#include "src/tree.h"
#include "src/file_struct.h"

int main(int argc, const char* argv[]) {
  test_stdin();
  FILE* f = NULL;
  return 0;
}

